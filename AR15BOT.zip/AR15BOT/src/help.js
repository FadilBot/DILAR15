const help = (prefix) => {
	
	                
┏━━━°❀ ❬ 𝗔𝗕𝗢𝗨𝗧 ❭ ❀°━━━┓
┃
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}creator*
┃
┣━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker* [foto]
┣➥ *${prefix}stickergif* [foto]
┣➥ *${prefix}sticker nobg 
┣➥ *${prefix}thunder* [teks]
┣➥ *${prefix}tsticker* [teks/url]
┃
┣━━━━°❀ ❬ 𝗠𝗘𝗗𝗜𝗔 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}tts* [teks]
┣➥ *${prefix}ocr*
┣➥ *${prefix}loli*
┣➥ *${prefix}toimg*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}wait* [foto]
┣➥ *${prefix}simi
┣➥ *${prefix}simih*
┣➥ *${prefix}wait*
┃
┣━━━━°❀ ❬ 𝗚𝗥𝗢𝗨𝗣 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}setname*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}getpp*
┣➥ *${prefix}tagall*
┣➥ *${prefix}linkgroup
┣➥ *${prefix}gprofile*
┣➥ *${prefix}setprefix
┣➥ *${prefix}welcome*
┣➥ *${prefix}left*
┃
┣━━━━°❀ ❬ 𝗦𝗢𝗨𝗡𝗗 ❭ ❀°━━━━━⊱
┃
┣➥ *salam*
┣➥ *tariksis*
┣➥ *baka*
┣➥ *desah*
┣➥ *goblok*
┣➥ *roti*
┣➥ *welot*
┣➥ *abangjago*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃𝙿𝚊𝚍𝚊 𝚋𝚘𝚝 𝚒𝚗𝚒 𝚔𝚎𝚋𝚊𝚗𝚢𝚊𝚔𝚊𝚗 
┃𝚑𝚊𝚗𝚢𝚊 𝚊𝚍𝚖𝚒𝚗 𝚍𝚊𝚗 𝚘𝚠𝚗𝚎𝚛
┃𝚢𝚊𝚗𝚐 𝚙𝚊𝚔𝚊𝚒  *^_^*
┣━━━━━━━━━━━━━━━━━━━━
┃      𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 𝗙𝗔𝗗𝗜𝗟
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.help = help

